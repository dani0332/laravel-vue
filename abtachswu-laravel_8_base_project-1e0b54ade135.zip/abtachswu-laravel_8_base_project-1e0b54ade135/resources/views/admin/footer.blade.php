<footer class="footer">
    <span>Copyright &copy; {{ date('Y') }} {{ CustomHelper::appSetting('application_setting','application_name') }}</span>
</footer>
