<div class="misc-header text-center">
    <img style="width: 30px;" alt="icon" src="{{ CustomHelper::appSetting('application_setting','favicon') }}" class="logo-icon">
    <img style="width: 165px;" alt="logo" src="{{ CustomHelper::appSetting('application_setting','logo') }}" class="toggle-none hidden-xs">
</div>
