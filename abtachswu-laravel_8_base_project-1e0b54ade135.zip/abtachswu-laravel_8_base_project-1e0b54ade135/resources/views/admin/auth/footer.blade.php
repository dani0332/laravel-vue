<div class="text-center misc-footer">
    <p>Copyright &copy; {{ date('Y') }} {{ CustomHelper::appSetting('application_setting','application_name') }}</p>
</div>
